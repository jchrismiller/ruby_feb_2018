FactoryGirl.define do
  factory :user do
    first_name "Chris"
    last_name "Miller"
    email "chris.miller@mail.com"
  end
end
