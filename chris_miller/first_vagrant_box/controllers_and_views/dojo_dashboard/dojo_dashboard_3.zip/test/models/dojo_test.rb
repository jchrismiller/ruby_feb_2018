require 'test_helper'

class DojoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
