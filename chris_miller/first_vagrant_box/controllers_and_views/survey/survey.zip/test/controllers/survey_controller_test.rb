require 'test_helper'

class SurveyControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
