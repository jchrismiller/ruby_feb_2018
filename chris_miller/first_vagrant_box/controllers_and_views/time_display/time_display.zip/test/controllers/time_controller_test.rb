require 'test_helper'

class TimeControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
