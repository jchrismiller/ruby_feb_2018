class UsersController < ApplicationController
  def show
    @current_user= User.find_by_id( params[:id])
    render 'show'
  end

end
