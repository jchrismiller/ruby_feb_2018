FactoryGirl.define do
  factory :user do
    name "chris"
    email "chris@mail.com"
    password "password"
    password_confirmation "password"
  end
end
