FactoryGirl.define do
  factory :user do
    name "MyString"
    email "chris@miller.com"
    password "password"
    password_confirmation "password"
  end
end
