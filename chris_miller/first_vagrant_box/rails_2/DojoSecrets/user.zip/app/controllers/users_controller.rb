class UsersController < ApplicationController
	
end
